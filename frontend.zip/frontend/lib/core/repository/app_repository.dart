
abstract class IAppRepository {
  // final AppDataProviderSingleton _appDataProviderSingleton;
  // AppRepository._(
  //   this._appDataProviderSingleton,
  // );

}
