# Rental-Services
## 
Rental services is a mobile app that connects property owners with users that want to rent.

## Features
1. Role based Authentication and Authorization
2. Filtering Rent services such as car rent, house rent ..
3. Rent Items CRUD operations.
4. Admin approval of Rent items.
5. Users can get location and contact info of property and property owners

## Group Memebers
